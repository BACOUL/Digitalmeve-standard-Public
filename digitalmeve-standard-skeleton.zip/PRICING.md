# Pricing Model (Draft)

## Free Tier
- 5 free certificates/month

## Individual
- Basic plan
- Unlimited personal use

## Pro
- DNS integration
- Private keys
- Bulk certificates

## Enterprise
- Custom integrations
- Support SLA
