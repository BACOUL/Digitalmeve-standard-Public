# DigitalMeve Standard (Draft)

## Overview
- Definition of the .MEVE certificate
- Required fields
- Hashing algorithm
- Timestamping rules

## Versioning
- v1 (current)
- v2 (future)
