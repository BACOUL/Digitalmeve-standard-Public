# Roadmap

## Phase 1 — MVP
- Certificate generation & verification (done)

## Phase 2 — Adoption
- Pro accounts
- DNS integration

## Phase 3 — Global Standard
- International adoption
- Legal recognition
