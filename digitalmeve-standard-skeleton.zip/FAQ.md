# FAQ

**Q: What is a .MEVE certificate?**
A: A lightweight file proving authenticity.

**Q: Do you store my files?**
A: No. Files never leave your device.

**Q: Is this legal proof?**
A: Yes, under digital evidence rules (varies by country).
