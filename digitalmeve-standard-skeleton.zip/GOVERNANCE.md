# Governance

## Committee
- Open contributions via GitHub
- Core maintainers

## Transparency
- All standards public
- Open roadmap
